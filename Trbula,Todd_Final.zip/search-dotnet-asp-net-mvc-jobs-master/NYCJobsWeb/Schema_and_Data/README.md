# NYC Jobs Demo Data & Schema 

This is the data used for the <a href="http://azure.microsoft.com/en-us/services/search/">Azure Search</a> Jobs demo website based on data from the <a href="https://nycopendata.socrata.com/">NYC Open Data initiative</a>.  Jobs listed here should not be considered active or accurate.

To import this data and schema, tool such as Fiddler or Chome Postman are convenient to allow you to paste the data from these files for import.  For more details on how to make a call to upload files using the Azure Search REST API, please visit: https://msdn.microsoft.com/en-us/library/azure/dn798930.aspx
